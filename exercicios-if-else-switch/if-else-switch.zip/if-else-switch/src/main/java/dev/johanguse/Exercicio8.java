package dev.johanguse;

public class Exercicio8 {

    public static void main(String[] args) {
        int jogadoresTimeA = 7;
        int jogadoresTimeB = 6;

        if (jogadoresTimeA < 7 || jogadoresTimeB < 7) {
            System.out.println("O jogo deve ser interrompido por falta de jogadores.");
        } else {
            System.out.println("O jogo pode prosseguir.");
        }
    }
}

