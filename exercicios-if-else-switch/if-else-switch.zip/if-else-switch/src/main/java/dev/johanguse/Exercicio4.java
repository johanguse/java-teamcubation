package dev.johanguse;

public class Exercicio4 {

    public static void main(String[] args) {
        int vitorias = 8;
        int derrotas = 9;

        if (vitorias > derrotas) {
            System.out.println("Desempenho positivo.");
        } else {
            System.out.println("Desempenho negativo.");
        }
    }
}
